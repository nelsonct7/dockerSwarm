const mongoose = require('mongoose');
const fs = require('fs')
require("dotenv").config();

const dbUrl=process.env.DB_URL || fs.readFileSync(process.env.DATABASE_URL_FILE, 'utf8');

const connectToDb=async(cb)=>{
    try{
        console.log("[!] DB URL ",dbUrl);
        await mongoose.connect(dbUrl)
        cb(dbUrl)
    }catch(error){
        console.log("[!] Failed to connect to db server ",error);
        throw error
    }
}


module.exports={
    connectToDb
}